
import { Button } from "./button";
import { Link2, Facebook, Twitter } from "lucide-react";

interface ShareButtonsProps {
  url: string;
  title: string;
}

export function ShareButtons({ url, title }: ShareButtonsProps) {
  const shareUrl = encodeURIComponent(url);
  const shareTitle = encodeURIComponent(title);

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(url);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  return (
    <div className="flex gap-2 ml-auto">
      <Button
        variant="outline"
        size="sm"
        className="hover:bg-neutral-100"
        onClick={copyToClipboard}
      >
        <Link2 className="mr-1 h-4 w-4" />
        Copy Link
      </Button>
      <Button
        variant="outline"
        size="sm"
        className="hover:bg-blue-50 text-blue-600 hover:text-blue-700"
        asChild
      >
        <a
          href={`https://www.facebook.com/sharer/sharer.php?u=${shareUrl}`}
          target="_blank"
          rel="noopener noreferrer"
        >
          <Facebook className="mr-1 h-4 w-4" />
          Share
        </a>
      </Button>
      <Button
        variant="outline"
        size="sm"
        className="hover:bg-green-50 text-green-600 hover:text-green-700"
        asChild
      >
        <a
          href={`https://wa.me/?text=${shareTitle}%0A${shareUrl}`}
          target="_blank"
          rel="noopener noreferrer"
        >
          <i className="fab fa-whatsapp mr-1" />
          Share
        </a>
      </Button>
      <Button
        variant="outline"
        size="sm"
        className="hover:bg-blue-50 text-blue-400 hover:text-blue-500"
        asChild
      >
        <a
          href={`https://twitter.com/intent/tweet?url=${shareUrl}&text=${shareTitle}`}
          target="_blank"
          rel="noopener noreferrer"
        >
          <Twitter className="mr-1 h-4 w-4" />
          Tweet
        </a>
      </Button>
    </div>
  );
}
