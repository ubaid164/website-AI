import bannerPath from "@assets/hadder.banner.png";

export default function Banner() {
  return (
    <section className="w-full">
      <div className="container mx-auto px-4 py-6">
        <img 
          src={bannerPath} 
          alt="Altarteel Academy Banner" 
          className="w-full rounded-lg shadow-md"
        />
      </div>
    </section>
  );
}
