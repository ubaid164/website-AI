import { useState, useEffect } from 'react';

export default function Welcome() {
  const [timeLeft, setTimeLeft] = useState({
    days: 3,
    hours: 24,
    minutes: 60,
    seconds: 60
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 };
        } else if (prev.days > 0) {
          return { ...prev, days: prev.days - 1, hours: 23, minutes: 59, seconds: 59 };
        }
        return prev;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <section className="bg-primary bg-opacity-5 py-12">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl font-bold text-white mb-4 font-display">Welcome to Altarteel Academy</h2>
        
        <div className="grid grid-cols-3 gap-4 max-w-3xl mx-auto mb-8">
          <div className="bg-white p-4 rounded-lg shadow">
            <div className="text-3xl font-bold text-primary">1000+</div>
            <div className="text-sm text-neutral-600">Students Enrolled</div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow">
            <div className="text-3xl font-bold text-primary">95%</div>
            <div className="text-sm text-neutral-600">Success Rate</div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow">
            <div className="text-3xl font-bold text-primary">24/7</div>
            <div className="text-sm text-neutral-600">Support Available</div>
          </div>
        </div>

        <div className="bg-amber-50 p-4 rounded-lg mb-8">
          <p className="text-amber-800 font-semibold mb-2">Special Shawwal Offer! Enroll Now</p>
          <div className="flex justify-center space-x-4">
            <div className="bg-white px-3 py-2 rounded">
              <span className="text-xl font-bold text-primary">{timeLeft.days}</span>
              <span className="text-sm text-neutral-600"> days</span>
            </div>
            <div className="bg-white px-3 py-2 rounded">
              <span className="text-xl font-bold text-primary">{timeLeft.hours}</span>
              <span className="text-sm text-neutral-600"> hours</span>
            </div>
            <div className="bg-white px-3 py-2 rounded">
              <span className="text-xl font-bold text-primary">{timeLeft.minutes}</span>
              <span className="text-sm text-neutral-600"> min</span>
            </div>
            <div className="bg-white px-3 py-2 rounded">
              <span className="text-xl font-bold text-primary">{timeLeft.seconds}</span>
              <span className="text-sm text-neutral-600"> sec</span>
            </div>
          </div>
        </div>
        
        <div className="max-w-3xl mx-auto bg-white p-6 rounded-lg shadow-md border-t-4 border-amber-500">
          <p className="text-xl mb-4 text-neutral-700">Learn Quran with Tajweed from Qualified Tutors</p>
          
          <div className="rtl font-arabic text-2xl text-primary mb-4">
            اقْرَءُوا الْقُرْآنَ فَإِنَّهُ يَأْتِي يَوْمَ الْقِيَامَةِ شَفِيعًا لِأَصْحَابِهِ
          </div>
          
          <p className="text-lg text-neutral-600 italic">
            "Recite the Quran, for it will come as an intercessor for its reciters on the Day of Resurrection."
            <span className="block text-sm mt-1">(Muslim)</span>
          </p>
        </div>
      </div>
    </section>
  );
}
