import { Card, CardContent } from "@/components/ui/card";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import { useQuery } from "@tanstack/react-query";

type Testimonial = {
  id: string;
  text: string;
  name: string;
  role: string;
};

export default function Testimonials() {
  const { data: testimonials = [], isLoading } = useQuery<Testimonial[]>({
    queryKey: ['/api/testimonials'],
  });

  return (
    <section className="py-16 bg-primary">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-white mb-4 font-display">What Our Students Say</h2>
          <p className="text-lg text-white max-w-3xl mx-auto">
            Read testimonials from our students who have experienced the quality of our Quranic education.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {isLoading ? (
            // Loading skeleton
            [...Array(3)].map((_, index) => (
              <Card key={index} className="shadow-md">
                <CardContent className="p-6">
                  <div className="h-24 bg-neutral-100 rounded animate-pulse mb-4" />
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-neutral-100 rounded-full animate-pulse" />
                    <div className="ml-4">
                      <div className="h-4 w-24 bg-neutral-100 rounded animate-pulse mb-2" />
                      <div className="h-3 w-20 bg-neutral-100 rounded animate-pulse" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            testimonials.map((testimonial) => (
              <Card key={testimonial.id} className="bg-white shadow-md relative">
                <CardContent className="p-6">
                  <div className="text-amber-500 text-4xl absolute -top-5 left-6">"</div>
                  <p className="text-neutral-700 mb-4 pt-4">
                    {testimonial.text}
                  </p>
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                      <i className="fas fa-user text-white"></i>
                    </div>
                    <div className="ml-4">
                      <h4 className="font-medium text-neutral-900">{testimonial.name}</h4>
                      <p className="text-sm text-neutral-600">{testimonial.role}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* Video Testimonial Section */}
        <div className="mt-16">
          <h3 className="text-2xl font-bold text-white text-center mb-8">Watch Our Student Testimonials</h3>
          <div className="max-w-6xl mx-auto px-4">
            <Carousel className="w-full">
              <CarouselContent>
                <CarouselItem className="md:basis-1/3">
                  <div className="bg-white rounded-lg shadow-lg overflow-hidden">
                    <div className="aspect-w-16 aspect-h-9">
                      <iframe 
                        className="w-full h-full"
                        src="https://www.youtube.com/embed/lgm3puP3tMA"
                        title="Student Testimonial 1"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                      ></iframe>
                    </div>
                  </div>
                </CarouselItem>
                <CarouselItem className="md:basis-1/3">
                  <div className="bg-white rounded-lg shadow-lg overflow-hidden">
                    <div className="aspect-w-16 aspect-h-9">
                      <iframe 
                        className="w-full h-full"
                        src="https://www.youtube.com/embed/tQHAwV9B8hQ"
                        title="Student Testimonial 2"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                      ></iframe>
                    </div>
                  </div>
                </CarouselItem>
                <CarouselItem className="md:basis-1/3">
                  <div className="bg-white rounded-lg shadow-lg overflow-hidden">
                    <div className="aspect-w-16 aspect-h-9">
                      <iframe 
                        className="w-full h-full"
                        src="https://www.youtube.com/embed/znyI0p4L-F0"
                        title="Student Testimonial 3"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                      ></iframe>
                    </div>
                  </div>
                </CarouselItem>
                <CarouselItem className="md:basis-1/3">
                  <div className="bg-white rounded-lg shadow-lg overflow-hidden">
                    <div className="aspect-w-16 aspect-h-9">
                      <iframe 
                        className="w-full h-full"
                        src="https://www.youtube.com/embed/NINIfRj_xBE"
                        title="Student Testimonial 4"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                      ></iframe>
                    </div>
                  </div>
                </CarouselItem>
              </CarouselContent>
              <CarouselPrevious className="hidden md:flex" />
              <CarouselNext className="hidden md:flex" />
            </Carousel>
          </div>
        </div>
      </div>
    </section>
  );
}