import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";

type Course = {
  id: string;
  title: string;
  description: string;
  icon: string;
  iconColor: string;
  bgColor: string;
  tags: string[];
};

export default function FeaturedCourses() {
  const { data: courses = [], isLoading } = useQuery<Course[]>({
    queryKey: ['/api/featured-courses'],
  });
  
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-black mb-4 font-display">Our Featured Courses</h2>
          <p className="text-lg text-neutral-600 max-w-3xl mx-auto">
            Join our specialized online courses taught by qualified instructors to learn Quran reading, 
            memorization, and understanding from anywhere in the world.
          </p>
        </div>
        
        {/* Featured Courses Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {isLoading ? (
            // Loading skeleton
            [...Array(3)].map((_, index) => (
              <Card key={index} className="border border-neutral-200">
                <div className="h-48 bg-neutral-100 animate-pulse" />
                <CardContent className="p-6">
                  <div className="h-6 bg-neutral-100 rounded animate-pulse mb-4" />
                  <div className="h-20 bg-neutral-100 rounded animate-pulse mb-4" />
                  <div className="flex flex-wrap gap-2 mb-4">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="h-6 w-20 bg-neutral-100 rounded-full animate-pulse" />
                    ))}
                  </div>
                  <div className="h-10 bg-neutral-100 rounded animate-pulse" />
                </CardContent>
              </Card>
            ))
          ) : (
            courses.map((course) => (
              <Card key={course.id} className="border border-neutral-200 hover:shadow-lg transition-shadow duration-300">
                <div className={`h-48 ${course.bgColor} flex items-center justify-center`}>
                  <i className={`${course.icon} text-5xl ${course.iconColor}`}></i>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold text-primary mb-2 font-display">{course.title}</h3>
                  <p className="text-neutral-600 mb-4">{course.description}</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {course.tags.map((tag, index) => (
                      <Badge key={index} variant="outline" className="bg-neutral-100 text-neutral-600">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  <Button asChild className="w-full bg-primary hover:bg-primary-dark">
                    <Link href={`/course/${course.id}`}>View Course Details</Link>
                  </Button>
                </CardContent>
              </Card>
            ))
          )}
        </div>
        
        {/* View All Courses Button */}
        <div className="text-center mt-12">
          <Button asChild className="bg-amber-500 hover:bg-amber-600 text-white font-medium py-3 px-8">
            <Link href="/courses">View All Courses</Link>
          </Button>
        </div>
      </div>
    </section>
  );
}
