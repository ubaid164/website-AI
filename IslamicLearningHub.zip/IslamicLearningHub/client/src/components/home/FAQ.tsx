
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const faqs = [
  {
    question: "How are the online Quran classes conducted?",
    answer: "Our classes are conducted live through our secure online platform. Each student gets individual attention in a one-on-one setting. We use advanced digital tools for clear audio and video communication, along with interactive Quran learning materials."
  },
  {
    question: "What do I need to start learning?",
    answer: "You'll need a stable internet connection, a device (computer, tablet, or smartphone), and a quiet space for learning. We'll provide all the necessary digital learning materials and guides to help you get started."
  },
  {
    question: "How long is each class session?",
    answer: "Each class session is typically 30-45 minutes long, depending on the course and student's level. We ensure the duration is optimal for maintaining focus and achieving learning objectives."
  },
  {
    question: "How do you monitor student progress?",
    answer: "We conduct monthly assessments for each student to evaluate their Quran reading progress and identify areas for improvement. Our quality assurance team generates detailed progress reports that teachers use to customize their teaching approach and focus on specific areas of development."
  },
  {
    question: "What is your teaching quality assurance process?",
    answer: "With permission from students or parents, we record classes for quality assurance purposes. Our expert panel reviews these sessions to ensure teaching excellence and provide constructive feedback to our teachers, maintaining our high educational standards."
  },
  {
    question: "What makes your Quran teachers special?",
    answer: "Our teachers understand the sacred responsibility of teaching the Quran, following the tradition of the Sahaba. They are punctual, demonstrate exemplary character, and possess deep knowledge. They serve as role models while delivering comprehensive Quranic education."
  },
  {
    question: "How are your teachers trained?",
    answer: "Before beginning their teaching journey, all our teachers undergo intensive training in modern teaching methodologies, student engagement, and effective online instruction techniques. This ensures they can deliver lessons effectively while maintaining Islamic educational principles."
  },
  {
    question: "Do you offer a money-back guarantee?",
    answer: "Yes! We offer a 100% money-back guarantee for your first demo course if you're not completely satisfied. We're confident in our teaching quality and want you to experience our classes risk-free."
  }
];

export default function FAQ() {
  return (
    <section className="py-16 bg-[url('/islamic-pattern.jpg')] bg-cover bg-center bg-opacity-10">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-primary mb-4 font-display">Frequently Asked Questions</h2>
          <p className="text-lg text-neutral-600 max-w-3xl mx-auto">
            Find answers to common questions about our Quranic education services
          </p>
        </div>
        
        <div className="max-w-3xl mx-auto bg-white/90 backdrop-blur-sm rounded-lg p-6 shadow-lg">
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger className="text-left">{faq.question}</AccordionTrigger>
                <AccordionContent>{faq.answer}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}
