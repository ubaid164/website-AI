import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function CallToAction() {
  return (
    <section className="py-16 bg-primary">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl font-bold mb-6 font-display text-white">Begin Your Quranic Journey Today</h2>
        <p className="text-xl mb-8 max-w-3xl mx-auto text-white">
          Take the first step towards mastering the Quran. Schedule a free trial class with one of our qualified tutors.
        </p>
        <div className="flex justify-center">
          <Button 
            asChild 
            className="bg-white text-primary hover:bg-neutral-100 relative overflow-hidden group animate-pulse"
          >
            <a 
              href="https://wa.me/923226878662?text=I%20would%20like%20to%20book%20a%20free%20trial%20class" 
              target="_blank" 
              rel="noopener noreferrer"
              className="relative z-10"
            >
              <span className="flex items-center">
                Get Free 1st Class
                <span className="ml-2 group-hover:translate-x-1 transition-transform">→</span>
              </span>
              <div className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/50 to-white/0 transform translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000"></div>
            </a>
          </Button>

        </div>
      </div>
    </section>
  );
}