import { Card, CardContent } from "@/components/ui/card";

const features = [
  {
    icon: "fas fa-user-tie",
    title: "Qualified Teachers",
    description: "Learn from certified Quran tutors with years of experience in teaching Tajweed and Quranic studies."
  },
  {
    icon: "fas fa-globe",
    title: "Flexible Schedule",
    description: "Choose class timings that fit your schedule. Available 24/7 for students from all around the world."
  },
  {
    icon: "fas fa-chalkboard-teacher",
    title: "Personalized Learning",
    description: "Tailored curriculum and teaching methods adapted to match your learning style and pace."
  },
  {
    icon: "fas fa-certificate",
    title: "Certification",
    description: "Receive recognized certificates upon successful completion of courses and assessments."
  }
];

export default function WhyChooseUs() {
  return (
    <section className="py-16 bg-neutral-100">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-black mb-4 font-display">Why Choose Altarteel Academy</h2>
          <p className="text-lg text-neutral-600 max-w-3xl mx-auto">
            We strive to provide the highest quality Quranic education with a focus on individual learning needs.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="border-t-4 border-primary text-center">
              <CardContent className="pt-6">
                <div className="text-primary mb-4">
                  <i className={`${feature.icon} text-4xl`}></i>
                </div>
                <h3 className="text-xl font-bold mb-2 font-display">{feature.title}</h3>
                <p className="text-neutral-600">
                  {feature.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
