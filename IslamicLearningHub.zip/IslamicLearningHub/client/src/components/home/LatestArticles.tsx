import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";

type Article = {
  id: string;
  title: string;
  titleArabic?: string;
  description: string;
  image: string;
};

export default function LatestArticles() {
  const { data: allArticles = [], isLoading } = useQuery<Article[]>({
    queryKey: ['/api/articles'],
  });
  
  const articles = allArticles.slice(0, 4);

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-primary mb-4 font-display">Latest Articles</h2>
          <p className="text-lg text-neutral-600 max-w-3xl mx-auto">
            Explore our educational resources and articles about Quran, Tajweed, and Islamic knowledge.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {isLoading ? (
            // Loading skeleton
            [...Array(3)].map((_, index) => (
              <Card key={index} className="border border-neutral-200">
                <div className="h-48 bg-neutral-100 animate-pulse" />
                <CardContent className="p-6">
                  <div className="h-6 bg-neutral-100 rounded animate-pulse mb-4" />
                  <div className="h-20 bg-neutral-100 rounded animate-pulse mb-4" />
                </CardContent>
                <CardFooter>
                  <div className="h-6 w-24 bg-neutral-100 rounded animate-pulse" />
                </CardFooter>
              </Card>
            ))
          ) : (
            articles.map((article) => (
              <Card key={article.id} className="border border-neutral-200 hover:shadow-lg transition-shadow duration-300">
                <div className="h-48 overflow-hidden">
                  <img src={article.image} alt={article.title} className="w-full h-full object-cover" />
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold text-primary mb-2 font-display">
                    {article.titleArabic && (
                      <span className="rtl font-arabic block mb-1">{article.titleArabic}</span>
                    )}
                    {article.title}
                  </h3>
                  <p className="text-neutral-600 mb-4">{article.description}</p>
                </CardContent>
                <CardFooter>
                  <Link href={`/article/${article.id}`} className="text-amber-500 hover:text-amber-600 font-medium inline-flex items-center">
                    Read More <i className="fas fa-arrow-right ml-2"></i>
                  </Link>
                </CardFooter>
              </Card>
            ))
          )}
        </div>
        
        {/* View All Articles Button */}
        <div className="text-center mt-12">
          <Link href="/articles" className="inline-block bg-neutral-200 hover:bg-neutral-300 text-neutral-700 font-medium py-3 px-8 rounded-md transition-colors duration-300">
            More Articles Coming Soon
          </Link>
        </div>
      </div>
    </section>
  );
}
