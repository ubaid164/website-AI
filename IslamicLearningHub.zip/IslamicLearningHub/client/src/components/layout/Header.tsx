import { useState } from "react";
import { Link } from "wouter";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu } from "lucide-react";
import logoPath from "@assets/462651865_1625671594694438_2687677736466869382_n-modified-150x150.png";

export default function Header() {
  const [isCoursesOpen, setIsCoursesOpen] = useState(false);
  const [isQuranOpen, setIsQuranOpen] = useState(false);

  const toggleCourses = () => setIsCoursesOpen(!isCoursesOpen);
  const toggleQuran = () => setIsQuranOpen(!isQuranOpen);

  return (
    <header className="bg-white shadow-md">
      {/* Top bar with contact info */}
      <div className="bg-primary text-white py-2 px-4 md:px-6">
        <div className="container mx-auto flex flex-col md:flex-row justify-between items-center text-sm">
          <div className="flex items-center space-x-4 mb-2 md:mb-0">
            <a href="mailto:contactus@altarteelacademy.com" className="flex items-center hover:text-secondary">
              <i className="fas fa-envelope mr-2"></i> contactus@altarteelacademy.com
            </a>
          </div>
          <div className="flex items-center space-x-4">
            <a href="tel:+923226878662" className="flex items-center hover:text-secondary">
              <i className="fas fa-phone-alt mr-2"></i> +92 322 6878662
            </a>
            <a href="tel:+923134820125" className="hidden sm:flex items-center hover:text-secondary">
              <i className="fas fa-phone-alt mr-2"></i> +92 313 4820125
            </a>
          </div>
        </div>
      </div>
      
      {/* Main header with logo and navigation */}
      <div className="container mx-auto px-4 py-4 flex flex-col md:flex-row justify-between items-center">
        {/* Logo */}
        <div className="flex items-center mb-4 md:mb-0">
          <img src={logoPath} alt="Altarteel Academy Logo" className="h-16 w-16" />
          <div className="ml-3">
            <h1 className="text-xl md:text-2xl font-bold text-primary font-display">Altarteel Academy</h1>
            <p className="text-neutral-500 text-sm">Learn Quran Online</p>
          </div>
        </div>
        
        {/* Desktop Navigation */}
        <nav className="hidden md:block">
          <ul className="flex space-x-6 text-neutral-600">
            <li>
              <Link href="/" className="hover:text-primary font-medium">Home</Link>
            </li>
            
            {/* Courses Dropdown */}
            <li className="dropdown relative group">
              <button className="hover:text-primary font-medium flex items-center">
                Courses <i className="fas fa-chevron-down ml-1 text-xs"></i>
              </button>
              <ul className="dropdown-menu hidden absolute left-0 mt-2 w-64 bg-white shadow-lg rounded-md py-2 z-50">
                <li><Link href="/course/memorization" className="block px-4 py-2 hover:bg-neutral-100">Learn Quran Memorization Online</Link></li>
                <li><Link href="/course/reading" className="block px-4 py-2 hover:bg-neutral-100">Learn Quran Reading</Link></li>
                <li><Link href="/course/tajweed" className="block px-4 py-2 hover:bg-neutral-100">Learn Tajweed Rules Online</Link></li>
                <li><Link href="/course/tafseer" className="block px-4 py-2 hover:bg-neutral-100">Learn Tafseer Online</Link></li>
                <li><Link href="/course/arabic" className="block px-4 py-2 hover:bg-neutral-100">Learn Arabic Online</Link></li>
              </ul>
            </li>
            
            {/* Learn Quran Online Dropdown */}
            <li className="dropdown relative group">
              <button className="hover:text-primary font-medium flex items-center">
                Learn Quran Online <i className="fas fa-chevron-down ml-1 text-xs"></i>
              </button>
              <ul className="dropdown-menu hidden absolute left-0 mt-2 w-48 bg-white shadow-lg rounded-md py-2 z-50">
                <li><Link href="/quran/read" className="block px-4 py-2 hover:bg-neutral-100">Read Quran Online</Link></li>
                <li><Link href="/quran/surahs" className="block px-4 py-2 hover:bg-neutral-100">Surahs</Link></li>
                <li><Link href="/quran/qaida" className="block px-4 py-2 hover:bg-neutral-100">Qaida</Link></li>
                <li><Link href="/quran/tajweed" className="block px-4 py-2 hover:bg-neutral-100">Tajweed Rules</Link></li>
                <li><Link href="/quran/prayers" className="block px-4 py-2 hover:bg-neutral-100">Prayers</Link></li>
                <li><Link href="/quran/supplications" className="block px-4 py-2 hover:bg-neutral-100">Supplications</Link></li>
                <li><Link href="/quran/hadith" className="block px-4 py-2 hover:bg-neutral-100">Short Hadith</Link></li>
              </ul>
            </li>
            
            <li>
              <Link href="/about" className="hover:text-primary font-medium">About Us</Link>
            </li>
            <li>
              <Link href="/contact" className="hover:text-primary font-medium">Contact</Link>
            </li>
          </ul>
        </nav>

        {/* Mobile menu button */}
        <Sheet>
          <SheetTrigger className="md:hidden p-2 rounded-md hover:bg-neutral-100">
            <Menu className="h-6 w-6" />
          </SheetTrigger>
          <SheetContent side="right" className="w-[300px] sm:w-[400px]">
            <nav className="mt-6">
              <ul className="space-y-4">
                <li>
                  <Link href="/" className="block py-2 text-lg font-medium">Home</Link>
                </li>
                
                {/* Mobile Courses Dropdown */}
                <li>
                  <button 
                    onClick={toggleCourses}
                    className="flex items-center justify-between w-full py-2 text-lg font-medium"
                  >
                    Courses
                    <i className={`fas fa-chevron-${isCoursesOpen ? 'up' : 'down'} ml-1`}></i>
                  </button>
                  {isCoursesOpen && (
                    <ul className="pl-4 mt-2 space-y-2">
                      <li><Link href="/course/memorization" className="block py-1">Learn Quran Memorization Online</Link></li>
                      <li><Link href="/course/reading" className="block py-1">Learn Quran Reading</Link></li>
                      <li><Link href="/course/tajweed" className="block py-1">Learn Tajweed Rules Online</Link></li>
                      <li><Link href="/course/tafseer" className="block py-1">Learn Tafseer Online</Link></li>
                      <li><Link href="/course/arabic" className="block py-1">Learn Arabic Online</Link></li>
                    </ul>
                  )}
                </li>
                
                {/* Mobile Learn Quran Online Dropdown */}
                <li>
                  <button 
                    onClick={toggleQuran}
                    className="flex items-center justify-between w-full py-2 text-lg font-medium"
                  >
                    Learn Quran Online
                    <i className={`fas fa-chevron-${isQuranOpen ? 'up' : 'down'} ml-1`}></i>
                  </button>
                  {isQuranOpen && (
                    <ul className="pl-4 mt-2 space-y-2">
                      <li><Link href="/quran/read" className="block py-1">Read Quran Online</Link></li>
                      <li><Link href="/quran/surahs" className="block py-1">Surahs</Link></li>
                      <li><Link href="/quran/qaida" className="block py-1">Qaida</Link></li>
                      <li><Link href="/quran/tajweed" className="block py-1">Tajweed Rules</Link></li>
                      <li><Link href="/quran/prayers" className="block py-1">Prayers</Link></li>
                      <li><Link href="/quran/supplications" className="block py-1">Supplications</Link></li>
                      <li><Link href="/quran/hadith" className="block py-1">Short Hadith</Link></li>
                    </ul>
                  )}
                </li>
                
                <li>
                  <Link href="/about" className="block py-2 text-lg font-medium">About Us</Link>
                </li>
                <li>
                  <Link href="/contact" className="block py-2 text-lg font-medium">Contact</Link>
                </li>
              </ul>
            </nav>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
}
