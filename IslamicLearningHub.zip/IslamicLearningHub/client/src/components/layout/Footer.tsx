import { Link } from "wouter";
import logoPath from "@assets/462651865_1625671594694438_2687677736466869382_n-modified-150x150.png";

export default function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* About */}
          <div>
            <div className="flex items-center mb-4">
              <img src={logoPath} alt="Altarteel Academy Logo" className="h-12 w-12" />
              <h3 className="text-xl font-bold ml-3 font-display">Altarteel Academy</h3>
            </div>
            <p className="text-gray-400 mb-4">
              Providing quality online Quranic education to students worldwide. Learn Quran with Tajweed from qualified tutors.
            </p>
            <div className="flex space-x-4">
              <a href="https://www.facebook.com/profile.php?id=61564663935778" className="text-gray-400 hover:text-white"><i className="fab fa-facebook-f"></i></a>
              <a href="http://ghulam.mustafa6878/" className="text-gray-400 hover:text-white"><i className="fab fa-twitter"></i></a>
              <a href="https://www.tiktok.com/@altarteel_academy" className="text-gray-400 hover:text-white"><i className="fab fa-tiktok"></i></a>
              <a href="https://www.youtube.com/@listenquranchannel6625" className="text-gray-400 hover:text-white"><i className="fab fa-youtube"></i></a>
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold mb-4 font-display">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link href="/" className="text-gray-400 hover:text-white">Home</Link></li>
              <li><Link href="/about" className="text-gray-400 hover:text-white">About Us</Link></li>
              <li><Link href="/course/reading" className="text-gray-400 hover:text-white">Courses</Link></li>
              <li><Link href="/faq" className="text-gray-400 hover:text-white">FAQs</Link></li>
              <li><Link href="/contact" className="text-gray-400 hover:text-white">Contact Us</Link></li>
            </ul>
          </div>
          
          {/* Courses */}
          <div>
            <h3 className="text-lg font-bold mb-4 font-display">Our Courses</h3>
            <ul className="space-y-2">
              <li><Link href="/course/reading" className="text-gray-400 hover:text-white">Quran Reading</Link></li>
              <li><Link href="/course/memorization" className="text-gray-400 hover:text-white">Quran Memorization (Hifz)</Link></li>
              <li><Link href="/course/tajweed" className="text-gray-400 hover:text-white">Tajweed Rules</Link></li>
              <li><Link href="/course/tafseer" className="text-gray-400 hover:text-white">Tafseer Classes</Link></li>
              <li><Link href="/course/arabic" className="text-gray-400 hover:text-white">Arabic Language</Link></li>
            </ul>
          </div>
          
          {/* Contact */}
          <div>
            <h3 className="text-lg font-bold mb-4 font-display">Contact Us</h3>
            <ul className="space-y-2">
              <li className="flex items-start">
                <i className="fas fa-envelope mt-1 mr-3 text-yellow-500"></i>
                <span className="text-gray-400">contactus@altarteelacademy.com</span>
              </li>
              <li className="flex items-start">
                <i className="fas fa-phone-alt mt-1 mr-3 text-yellow-500"></i>
                <div className="text-gray-400">
                  <p>+92 322 6878662</p>
                  <p>+92 313 4820125</p>
                </div>
              </li>
              <li className="flex items-start">
                <i className="fas fa-clock mt-1 mr-3 text-yellow-500"></i>
                <span className="text-gray-400">Available 24/7</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-10 pt-6 text-center">
          <p className="text-gray-500">
            &copy; {currentYear} Altarteel Academy. All Rights Reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
