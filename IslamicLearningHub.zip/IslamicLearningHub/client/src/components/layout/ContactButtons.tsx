export default function ContactButtons() {
  return (
    <>
      {/* WhatsApp Button (Left) */}
      <a 
        href="https://wa.me/923226878662" 
        className="fixed left-5 bottom-24 z-50 bg-green-500 hover:bg-green-600 text-white rounded-full p-3 shadow-lg transition-all duration-300"
        aria-label="Contact us on WhatsApp"
      >
        <i className="fab fa-whatsapp text-2xl"></i>
      </a>
      
      {/* Skype Button (Right) */}
      <a 
        href="skype:live:.cid.altarteelacademy" 
        className="fixed right-5 bottom-24 z-50 bg-blue-500 hover:bg-blue-600 text-white rounded-full p-3 shadow-lg transition-all duration-300"
        aria-label="Contact us on Skype"
      >
        <i className="fab fa-skype text-2xl"></i>
      </a>
    </>
  );
}
