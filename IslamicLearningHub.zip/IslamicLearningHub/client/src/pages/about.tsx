import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import logoPath from "@assets/462651865_1625671594694438_2687677736466869382_n-modified-150x150.png";

export default function About() {
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="text-center mb-12">
        <h1 className="text-3xl md:text-4xl font-bold text-primary mb-4 font-display">About Altarteel Academy</h1>
        <p className="text-lg text-neutral-600 max-w-3xl mx-auto">
          Discover our journey, mission, and commitment to providing quality Quranic education worldwide.
        </p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
        <div>
          <h2 className="text-2xl font-bold text-primary mb-6 font-display">Our Story</h2>
          <div className="prose max-w-none">
            <p>
              Altarteel Academy was founded with a simple yet profound mission: to make quality Quranic education 
              accessible to Muslims around the world. Our name "Altarteel" comes from the Quranic instruction to 
              recite the Quran with measured rhythmic tones (tarteel).
            </p>
            <p>
              What started as a small initiative has grown into a comprehensive online academy serving students 
              from various countries, backgrounds, and age groups. We believe that learning the Quran is a lifelong 
              journey that should be available to everyone regardless of their location or schedule constraints.
            </p>
            <p>
              Our team of qualified tutors combines traditional Islamic knowledge with modern teaching methodologies 
              to deliver an effective and engaging learning experience. Each instructor undergoes rigorous screening 
              and training to ensure they meet our high standards of Quranic knowledge and teaching ability.
            </p>
          </div>
        </div>
        
        <div className="flex items-center justify-center">
          <Card className="w-full max-w-md">
            <CardContent className="p-8 text-center">
              <img src={logoPath} alt="Altarteel Academy Logo" className="mx-auto h-32 w-32 mb-6" />
              <h3 className="text-xl font-bold text-primary mb-2 font-display">Altarteel Academy</h3>
              <p className="text-neutral-600 mb-6">Providing Quality Quranic Education Since 2018</p>
              <div className="rtl font-arabic text-xl text-primary mb-4">
                وَرَتِّلِ الْقُرْآنَ تَرْتِيلًا
              </div>
              <p className="italic text-neutral-600">
                "And recite the Quran with measured rhythmic tones."
                <span className="block text-sm mt-1">(Quran 73:4)</span>
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
      
      <div className="mb-16">
        <h2 className="text-2xl font-bold text-primary mb-6 font-display text-center">Our Vision & Mission</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <Card>
            <CardContent className="p-6">
              <div className="text-primary mb-4 text-center">
                <i className="fas fa-eye text-4xl"></i>
              </div>
              <h3 className="text-xl font-bold text-center mb-4 font-display">Our Vision</h3>
              <p className="text-neutral-600">
                To be the leading online Quranic academy known for excellence in teaching, personalized learning experiences, 
                and fostering a deep connection with the Quran among Muslims worldwide.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="text-primary mb-4 text-center">
                <i className="fas fa-bullseye text-4xl"></i>
              </div>
              <h3 className="text-xl font-bold text-center mb-4 font-display">Our Mission</h3>
              <p className="text-neutral-600">
                To provide accessible, high-quality Quranic education through innovative online teaching methods, 
                personalized instruction, and a supportive learning environment that helps students develop a 
                lifelong relationship with the Quran.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
      
      <div className="mb-16">
        <h2 className="text-2xl font-bold text-primary mb-6 font-display text-center">Our Values</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="text-amber-500 mb-4 text-center">
                <i className="fas fa-star text-3xl"></i>
              </div>
              <h3 className="text-lg font-bold text-center mb-3 font-display">Excellence</h3>
              <p className="text-neutral-600 text-center">
                We strive for excellence in our teaching methods, curriculum design, and student support.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="text-amber-500 mb-4 text-center">
                <i className="fas fa-user-friends text-3xl"></i>
              </div>
              <h3 className="text-lg font-bold text-center mb-3 font-display">Personalization</h3>
              <p className="text-neutral-600 text-center">
                We recognize each student's unique learning style and adapt our teaching accordingly.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="text-amber-500 mb-4 text-center">
                <i className="fas fa-heart text-3xl"></i>
              </div>
              <h3 className="text-lg font-bold text-center mb-3 font-display">Respect</h3>
              <p className="text-neutral-600 text-center">
                We respect the sacred nature of the Quran and ensure our teaching methods honor its sanctity.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="text-amber-500 mb-4 text-center">
                <i className="fas fa-globe text-3xl"></i>
              </div>
              <h3 className="text-lg font-bold text-center mb-3 font-display">Inclusivity</h3>
              <p className="text-neutral-600 text-center">
                We welcome students of all backgrounds and provide an inclusive learning environment.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="text-amber-500 mb-4 text-center">
                <i className="fas fa-graduation-cap text-3xl"></i>
              </div>
              <h3 className="text-lg font-bold text-center mb-3 font-display">Continuous Learning</h3>
              <p className="text-neutral-600 text-center">
                We encourage lifelong learning and continuous improvement in Quranic studies.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="text-amber-500 mb-4 text-center">
                <i className="fas fa-hands-helping text-3xl"></i>
              </div>
              <h3 className="text-lg font-bold text-center mb-3 font-display">Support</h3>
              <p className="text-neutral-600 text-center">
                We provide comprehensive support to all our students throughout their learning journey.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
      
      <div className="text-center bg-primary bg-opacity-5 py-12 px-4 rounded-lg">
        <h2 className="text-2xl font-bold text-primary mb-4 font-display">Ready to Begin Your Quranic Journey?</h2>
        <p className="text-lg text-neutral-600 max-w-2xl mx-auto mb-6">
          Join Altarteel Academy today and take the first step towards mastering the Quran with our expert tutors.
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Button asChild className="bg-primary hover:bg-primary-dark">
            <Link href="/courses">Explore Our Courses</Link>
          </Button>
          <Button asChild variant="outline">
            <Link href="/contact">Contact Us</Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
