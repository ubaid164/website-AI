import Banner from "@/components/home/Banner";
import Welcome from "@/components/home/Welcome";
import FeaturedCourses from "@/components/home/FeaturedCourses";
import WhyChooseUs from "@/components/home/WhyChooseUs";
import LatestArticles from "@/components/home/LatestArticles";
import FAQ from "@/components/home/FAQ";
import Testimonials from "@/components/home/Testimonials";
import CallToAction from "@/components/home/CallToAction";

export default function Home() {
  return (
    <>
      <Banner />
      <Welcome />
      <FeaturedCourses />
      <WhyChooseUs />
      <LatestArticles />
      <FAQ />
      <Testimonials />
      <CallToAction />
    </>
  );
}
