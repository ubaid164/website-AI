import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Link, useParams, useRoute } from "wouter";
import { Button } from "@/components/ui/button";

type Article = {
  id: string;
  title: string;
  titleArabic?: string;
  description: string;
  image: string;
  category: string;
  date: string;
};

const ShareButtons = ({ url, title }: { url: string; title: string }) => {
  return (
    <div className="flex space-x-2">
      <a
        href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}&t=${encodeURIComponent(title)}`}
        target="_blank"
        rel="noopener noreferrer"
        className="text-blue-500 hover:text-blue-700"
      >
        <i className="fab fa-facebook-square"></i>
      </a>
      <a
        href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(title)}&url=${encodeURIComponent(url)}`}
        target="_blank"
        rel="noopener noreferrer"
        className="text-blue-400 hover:text-blue-600"
      >
        <i className="fab fa-twitter-square"></i>
      </a>
      <a
        href={`https://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(url)}&title=${encodeURIComponent(title)}`}
        target="_blank"
        rel="noopener noreferrer"
        className="text-blue-700 hover:text-blue-900"
      >
        <i className="fab fa-linkedin"></i>
      </a>
    </div>
  );
};


export default function Articles() {
  const [match, params] = useRoute('/article/:id');
  const articleId = params?.id;

  const { data: articles = [], isLoading } = useQuery<Article[]>({
    queryKey: ['/api/articles/all'],
  });

  // If we're on the article detail page
  if (articleId) {
    const article = articles.find(a => a.id === articleId);

    if (isLoading) {
      return (
        <div className="container mx-auto px-4 py-16">
          <div className="animate-pulse max-w-4xl mx-auto">
            <div className="h-10 bg-neutral-100 rounded w-1/3 mb-6"></div>
            <div className="h-6 bg-neutral-100 rounded w-2/3 mb-8"></div>
            <div className="h-64 bg-neutral-100 rounded mb-8"></div>
            <div className="space-y-4">
              <div className="h-4 bg-neutral-100 rounded"></div>
              <div className="h-4 bg-neutral-100 rounded"></div>
              <div className="h-4 bg-neutral-100 rounded"></div>
              <div className="h-4 bg-neutral-100 rounded w-2/3"></div>
            </div>
          </div>
        </div>
      );
    }

    if (!article) {
      return (
        <div className="container mx-auto px-4 py-16 text-center">
          <h2 className="text-2xl font-bold text-red-500 mb-4">Article Not Found</h2>
          <p className="mb-6">Sorry, we couldn't find the article you're looking for.</p>
          <Button asChild>
            <Link href="/articles">Back to Articles</Link>
          </Button>
        </div>
      );
    }

    return (
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          {/* Back to Articles Link */}
          <Link href="/articles" className="text-primary hover:text-primary-dark inline-flex items-center mb-8">
            <i className="fas fa-arrow-left mr-2"></i> Back to Articles
          </Link>

          {/* Article Header */}
          <div className="mb-8">
            <span className="text-sm text-amber-500 mb-2 block">{article.category} • {article.date}</span>
            <div className="flex justify-between items-start mb-6">
              <h1 className="text-3xl md:text-4xl font-bold text-primary mb-4 font-display">
                {article.titleArabic && (
                  <span className="rtl font-arabic block mb-2">{article.titleArabic}</span>
                )}
                {article.title}
              </h1>
              <ShareButtons url={window.location.href} title={article.title} />
            </div>
          </div>

          {/* Article Featured Image */}
          <div className="mb-8 rounded-lg overflow-hidden">
            <img src={article.image} alt={article.title} className="w-full h-auto" />
          </div>

          {/* Article Content */}
          <div className="prose max-w-none">
            <p className="text-lg">{article.description}</p>

            {/* Placeholder article content based on the article topic - simplified language */}
            {article.id === "tajweed-importance" && (
              <div>
                <h2>What is Tajweed?</h2>
                <p>Tajweed means reading the Quran in the right way. It helps us say each letter correctly.</p>

                <h3>Why is Tajweed important?</h3>
                <p>When we read the Quran with Tajweed:</p>
                <ul>
                  <li>We show respect to Allah's words</li>
                  <li>We understand the meaning better</li>
                  <li>We get more rewards from Allah</li>
                </ul>

                <h3>Basic Tajweed Rules</h3>
                <p>Here are some simple rules to start with:</p>
                <ul>
                  <li>Say each letter from its right place in your mouth</li>
                  <li>Give each letter its full sound</li>
                  <li>Know when to stop and when to continue</li>
                </ul>
              </div>
            )}

            {(article.id === "urdu-tajweed" || article.id === "urdu-quran-learning" || article.id === "urdu-ramadan") && (
              <div className="rtl font-urdu">
                {article.id === "urdu-tajweed" && (
                  <>
                    <h2>تجوید کیا ہے؟</h2>
                    <p>تجوید کا مطلب ہے قرآن پاک کو صحیح طریقے سے پڑھنا۔ یہ ہمیں ہر حرف کو درست طریقے سے ادا کرنے میں مدد کرتا ہے۔</p>

                    <h3>تجوید کی اہمیت کیوں ہے؟</h3>
                    <p>جب ہم قرآن کو تجوید کے ساتھ پڑھتے ہیں:</p>
                    <ul>
                      <li>ہم اللہ کے کلام کا احترام کرتے ہیں</li>
                      <li>ہم معنی کو بہتر سمجھتے ہیں</li>
                      <li>ہمیں اللہ سے زیادہ ثواب ملتا ہے</li>
                    </ul>

                    <h3>تجوید کے بنیادی قواعد</h3>
                    <p>یہاں کچھ سادہ اصول ہیں جن سے آپ شروعات کر سکتے ہیں:</p>
                    <ul>
                      <li>ہر حرف کو منہ میں اس کی صحیح جگہ سے ادا کریں</li>
                      <li>ہر حرف کو اس کی پوری آواز دیں</li>
                      <li>جانیں کہ کب رکنا ہے اور کب جاری رکھنا ہے</li>
                    </ul>

                    <div className="my-6 p-5 bg-primary text-white rounded">
                      <p className="text-lg">قرآن پاک میں اللہ تعالی فرماتے ہیں:</p>
                      <div className="font-arabic text-2xl my-4">
                        وَرَتِّلِ الْقُرْآنَ تَرْتِيلًا
                      </div>
                      <p>اور قرآن کو ٹھہر ٹھہر کر پڑھو۔ (سورۃ المزمل: ٤)</p>
                    </div>
                  </>
                )}

                {article.id === "urdu-quran-learning" && (
                  <>
                    <h2>قرآن سیکھنے کے اصول</h2>
                    <p>قرآن مجید سیکھنا ہر مسلمان پر فرض ہے۔ اس کے لیے کچھ بنیادی اصول ہیں جن پر عمل کرکے آپ آسانی سے قرآن سیکھ سکتے ہیں۔</p>

                    <h3>بچوں کے لیے قرآن سیکھنے کے طریقے</h3>
                    <ul>
                      <li>پہلے قاعدہ سے شروع کریں</li>
                      <li>روزانہ تھوڑا تھوڑا پڑھیں</li>
                      <li>حروف کی صحیح ادائیگی پر توجہ دیں</li>
                      <li>اچھے استاد کی نگرانی میں سیکھیں</li>
                    </ul>

                    <h3>بڑوں کے لیے قرآن سیکھنے کے طریقے</h3>
                    <p>بڑی عمر میں بھی قرآن سیکھنا ممکن ہے، بس ذہن میں یہ رکھیں:</p>
                    <ul>
                      <li>کبھی بھی دیر نہیں ہوتی</li>
                      <li>ہمت نہ ہاریں</li>
                      <li>مسلسل پریکٹس کریں</li>
                      <li>آن لائن کلاسز سے فائدہ اٹھائیں</li>
                    </ul>

                    <div className="my-6 p-5 bg-primary text-white rounded">
                      <p className="text-lg">حدیث شریف:</p>
                      <div className="font-arabic text-xl my-4">
                        خَيْرُكُمْ مَنْ تَعَلَّمَ الْقُرْآنَ وَعَلَّمَهُ
                      </div>
                      <p>تم میں بہترین وہ ہے جو قرآن سیکھے اور سکھائے۔ (صحیح بخاری)</p>
                    </div>
                  </>
                )}

                {article.id === "urdu-ramadan" && (
                  <>
                    <h2>رمضان اور قرآن کا تعلق</h2>
                    <p>رمضان المبارک وہ مہینہ ہے جس میں قرآن مجید نازل ہوا۔ اس مہینے میں قرآن پڑھنے، سننے اور سمجھنے کی فضیلت بہت زیادہ ہے۔</p>

                    <h3>رمضان میں قرآن پڑھنے کے فوائد</h3>
                    <ul>
                      <li>اللہ تعالی کی رحمت اور برکت حاصل ہوتی ہے</li>
                      <li>گناہوں کی معافی ملتی ہے</li>
                      <li>روحانی سکون ملتا ہے</li>
                      <li>جنت میں اعلی درجات ملتے ہیں</li>
                    </ul>

                    <h3>رمضان میں قرآن سے تعلق بڑھانے کے طریقے</h3>
                    <ul>
                      <li>روزانہ کم از کم ایک پارہ پڑھیں</li>
                      <li>تراویح میں قرآن سنیں</li>
                      <li>قرآن کے معانی سمجھنے کی کوشش کریں</li>
                      <li>قرآن کی تلاوت کرنے والوں کی مجالس میں شریک ہوں</li>
                    </ul>

                    <div className="my-6 p-5 bg-primary text-white rounded">
                      <p className="text-lg">قرآن پاک میں اللہ تعالی فرماتے ہیں:</p>
                      <div className="font-arabic text-2xl my-4">
                        شَهْرُ رَمَضَانَ الَّذِي أُنْزِلَ فِيهِ الْقُرْآنُ
                      </div>
                      <p>رمضان کا مہینہ وہ ہے جس میں قرآن اتارا گیا۔ (سورۃ البقرہ: ١٨٥)</p>
                    </div>
                  </>
                )}
              </div>
            )}

            {article.id !== "tajweed-importance" && article.id !== "urdu-tajweed" && article.id !== "urdu-quran-learning" && article.id !== "urdu-ramadan" && (
              <div>
                <p>This article provides valuable information about {article.title.toLowerCase()}. The content aims to help readers better understand this topic and improve their Quranic studies.</p>

                <p>When studying the Quran, it's important to approach it with dedication and consistency. Regular practice makes perfect, and having a good teacher can make a big difference in your learning journey.</p>

                <div className="mt-8 p-6 bg-primary text-white rounded">
                  <h3 className="text-lg font-bold mb-2">Important Reminder</h3>
                  <p className="italic">The Holy Quran says:</p>
                  <div className="rtl font-arabic text-xl my-4">
                    {article.id === "memorization-techniques" && "وَلَقَدْ يَسَّرْنَا الْقُرْآنَ لِلذِّكْرِ فَهَلْ مِن مُّدَّكِرٍ"}
                    {article.id === "arabic-learning" && "كِتَابٌ أَنزَلْنَاهُ إِلَيْكَ مُبَارَكٌ لِّيَدَّبَّرُوا آيَاتِهِ"}
                    {article.id === "ramadan-preparation" && "شَهْرُ رَمَضَانَ الَّذِي أُنزِلَ فِيهِ الْقُرْآنُ"}
                    {article.id === "quranic-etiquette" && "إِنَّا نَحْنُ نَزَّلْنَا الذِّكْرَ وَإِنَّا لَهُ لَحَافِظُونَ"}
                    {article.id === "quran-rules" && "فَاقْرَءُوا مَا تَيَسَّرَ مِنَ الْقُرْآنِ"}
                  </div>
                  <p>Always approach the Quran with sincerity and dedication.</p>
                </div>
              </div>
            )}

            {/* Contact CTA */}
            <div className="mt-12 bg-primary text-white p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-2">Want to Learn More?</h3>
              <p className="mb-4">Join our online classes to deepen your Quranic knowledge with qualified teachers.</p>
              <Button asChild className="bg-white text-primary hover:bg-neutral-100">
                <a 
                  href={`https://wa.me/923226878662?text=I%20read%20your%20article%20"${encodeURIComponent(article.title)}"%20and%20would%20like%20to%20learn%20more.%0A%0AArticle%20Link:%20${encodeURIComponent(window.location.href)}`}
                  target="_blank" 
                  rel="noopener noreferrer"
                >
                  Contact Us for Classes
                </a>
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // If we're on the articles listing page
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="text-center mb-12">
        <h1 className="text-3xl md:text-4xl font-bold text-primary mb-4 font-display">Our Articles & Resources</h1>
        <p className="text-lg text-neutral-600 max-w-3xl mx-auto">
          Explore our collection of articles, resources, and guides on Quran, Tajweed, and Islamic knowledge.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {isLoading ? (
          // Loading skeleton
          [...Array(6)].map((_, index) => (
            <Card key={index} className="border border-neutral-200">
              <div className="h-48 bg-neutral-100 animate-pulse" />
              <CardContent className="p-6">
                <div className="h-6 bg-neutral-100 rounded animate-pulse mb-4" />
                <div className="h-20 bg-neutral-100 rounded animate-pulse mb-4" />
              </CardContent>
              <CardFooter className="px-6 py-4 border-t border-neutral-100 flex justify-between">
                <div className="h-4 w-24 bg-neutral-100 rounded animate-pulse" />
                <div className="h-4 w-16 bg-neutral-100 rounded animate-pulse" />
              </CardFooter>
            </Card>
          ))
        ) : articles.length > 0 ? (
          articles.map((article) => (
            <Card key={article.id} className="border border-neutral-200 hover:shadow-lg transition-shadow duration-300">
              <div className="h-48 overflow-hidden">
                <img src={article.image} alt={article.title} className="w-full h-full object-cover" />
              </div>
              <CardContent className="p-6">
                <span className="text-sm text-amber-500 mb-2 block">{article.category}</span>
                <h3 className="text-xl font-bold text-primary mb-2 font-display">
                  {article.titleArabic && (
                    <span className="rtl font-arabic block mb-1">{article.titleArabic}</span>
                  )}
                  {article.title}
                </h3>
                <p className="text-neutral-600 mb-4">{article.description}</p>
              </CardContent>
              <CardFooter className="px-6 py-4 border-t border-neutral-100 flex justify-between">
                <Link href={`/article/${article.id}`} className="text-amber-500 hover:text-amber-600 font-medium inline-flex items-center">
                  Read More <i className="fas fa-arrow-right ml-2"></i>
                </Link>
                <span className="text-neutral-500 text-sm">{article.date}</span>
              </CardFooter>
            </Card>
          ))
        ) : (
          <div className="col-span-full text-center py-16">
            <h3 className="text-xl font-medium text-neutral-500 mb-2">Articles Coming Soon!</h3>
            <p className="text-neutral-400">
              We're preparing some informative articles for you. Please check back later.
            </p>
          </div>
        )}
      </div>

      {/* Optional "Articles Coming Soon" Message */}
      {articles.length > 0 && (
        <div className="text-center mt-16 p-8 bg-neutral-50 rounded-lg">
          <h3 className="text-xl font-medium text-primary mb-2">More Articles Coming Soon!</h3>
          <p className="text-neutral-600 mb-0">
            We're working on more educational content. Check back regularly for updates.
          </p>
        </div>
      )}
    </div>
  );
}