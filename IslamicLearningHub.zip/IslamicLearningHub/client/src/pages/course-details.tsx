import { useRoute } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

type CourseDetails = {
  id: string;
  title: string;
  description: string;
  icon: string;
  iconColor: string;
  bgColor: string;
  tags: string[];
  longDescription: string;
  curriculum: string[];
  requirements: string[];
  outcomes: string[];
  price: string;
  duration: string;
  level: string;
  instructor: string;
  language: string;
  certificateOffered: boolean;
};

// Placeholder ShareButtons component
const ShareButtons = ({ url, title }: { url: string; title: string }) => {
  return (
    <div className="flex space-x-2">
      <Button variant="ghost" size="icon">
        <a href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}&t=${encodeURIComponent(title)}`} target="_blank" rel="noopener noreferrer">
          <i className="fab fa-facebook"></i>
        </a>
      </Button>
      <Button variant="ghost" size="icon">
        <a href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(title)}&url=${encodeURIComponent(url)}`} target="_blank" rel="noopener noreferrer">
          <i className="fab fa-twitter"></i>
        </a>
      </Button>
      {/* Add more share buttons as needed */}
    </div>
  );
};


export default function CourseDetails() {
  const [match, params] = useRoute('/course/:id');
  const courseId = params?.id;

  const { data: course, isLoading, error } = useQuery<CourseDetails>({
    queryKey: [`/api/courses/${courseId}`],
    enabled: !!courseId,
  });

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-16">
        <div className="animate-pulse">
          <div className="h-10 bg-neutral-100 rounded w-1/3 mb-6"></div>
          <div className="h-6 bg-neutral-100 rounded w-2/3 mb-8"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="md:col-span-2">
              <div className="h-40 bg-neutral-100 rounded mb-6"></div>
              <div className="h-4 bg-neutral-100 rounded mb-3"></div>
              <div className="h-4 bg-neutral-100 rounded mb-3"></div>
              <div className="h-4 bg-neutral-100 rounded mb-3"></div>
            </div>
            <div className="h-64 bg-neutral-100 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !course) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h2 className="text-2xl font-bold text-red-500 mb-4">Error Loading Course</h2>
        <p className="mb-6">Sorry, we couldn't load the course details.</p>
        <Button asChild>
          <Link href="/courses">Back to Courses</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="mb-8">
        <div className="flex justify-between items-start mb-6">
          <h1 className="text-3xl md:text-4xl font-bold text-primary mb-4 font-display">{course.title}</h1>
          <ShareButtons url={window.location.href} title={course.title} />
        </div>
        <p className="text-lg text-black max-w-3xl mb-6">{course.description}</p>
        <div className="flex flex-wrap gap-2 mb-6">
          {course.tags.map((tag, index) => (
            <Badge key={index} variant="outline" className="bg-neutral-100 text-neutral-600">
              {tag}
            </Badge>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Course Details */}
        <div className="md:col-span-2">
          <Tabs defaultValue="overview">
            <TabsList className="mb-6">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="curriculum">Curriculum</TabsTrigger>
              <TabsTrigger value="requirements">Requirements</TabsTrigger>
              <TabsTrigger value="outcomes">Outcomes</TabsTrigger>
            </TabsList>

            <TabsContent value="overview">
              <div className="prose max-w-none">
                <p className="whitespace-pre-line text-black">{course.longDescription}</p>
              </div>
            </TabsContent>

            <TabsContent value="curriculum">
              <div className="space-y-4">
                {course.curriculum.map((item, index) => (
                  <div key={index} className="flex items-start">
                    <i className="fas fa-check-circle text-green-500 mt-1 mr-3"></i>
                    <p className="text-black">{item}</p>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="requirements">
              <div className="space-y-4">
                {course.requirements.map((item, index) => (
                  <div key={index} className="flex items-start">
                    <i className="fas fa-circle text-xs text-neutral-400 mt-2 mr-3"></i>
                    <p className="text-black">{item}</p>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="outcomes">
              <div className="space-y-4">
                {course.outcomes.map((item, index) => (
                  <div key={index} className="flex items-start">
                    <i className="fas fa-check-circle text-green-500 mt-1 mr-3"></i>
                    <p className="text-black">{item}</p>
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Course Info Card */}
        <div>
          <Card className="border border-neutral-200 sticky top-6">
            <div className={`p-6 ${course.bgColor} flex items-center justify-center`}>
              <i className={`${course.icon} text-5xl ${course.iconColor}`}></i>
            </div>
            <CardContent className="p-6">
              <div className="space-y-4 mb-6">
                <div className="flex justify-between">
                  <span className="font-medium text-black">Price:</span>
                  <span className="text-black">{course.price}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium text-black">Duration:</span>
                  <span className="text-black">{course.duration}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium text-black">Level:</span>
                  <span className="text-black">{course.level}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium text-black">Instructor:</span>
                  <span className="text-black">{course.instructor}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium text-black">Language:</span>
                  <span className="text-black">{course.language}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium text-black">Certificate:</span>
                  <span className="text-black">{course.certificateOffered ? 'Yes' : 'No'}</span>
                </div>
              </div>

              <div className="space-y-3">
                <Button asChild className="w-full bg-primary hover:bg-primary-dark">
                  <a 
                    href={`https://wa.me/923226878662?text=I%20am%20interested%20in%20enrolling%20for%20the%20${encodeURIComponent(course.title)}%20course.%0A%0ACourse%20Link:%20${encodeURIComponent(window.location.href)}`} 
                    target="_blank" 
                    rel="noopener noreferrer"
                  >
                    Enroll Now
                  </a>
                </Button>
                <Button asChild variant="outline" className="w-full">
                  <a 
                    href={`https://wa.me/923226878662?text=I%20would%20like%20to%20book%20a%20free%20trial%20for%20the%20${encodeURIComponent(course.title)}%20course.%0A%0ACourse%20Link:%20${encodeURIComponent(window.location.href)}`} 
                    target="_blank" 
                    rel="noopener noreferrer"
                  >
                    Book Free Trial
                  </a>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}