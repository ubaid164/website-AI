// Course data
export const featuredCourses = [
  {
    id: "reading",
    title: "Learn Quran Reading",
    description: "Master the basics of Quran reading with proper pronunciation and articulation points.",
    icon: "fas fa-book-open",
    iconColor: "text-amber-500",
    bgColor: "bg-amber-500 bg-opacity-20",
    tags: ["Beginner", "1-on-1 Classes", "Certificate"],
    longDescription: `Our Quran Reading course is designed for beginners who want to learn how to read the Quran correctly with proper pronunciation. 

This comprehensive course covers all the basic rules of recitation, starting from recognizing Arabic letters and their sounds to connecting them into words and sentences.

Throughout the course, you will receive personalized guidance from experienced tutors who will help you develop proper articulation (makharij) of Arabic letters and improve your fluency in reading Quranic text.`,
    curriculum: [
      "Introduction to Arabic alphabet and their forms",
      "Recognizing and pronouncing Arabic letters correctly",
      "Understanding vowels (Fatha, Damma, Kasra)",
      "Reading words and simple sentences",
      "Introduction to Tajweed rules",
      "Practice reading from selected Surahs",
      "Reading with proper articulation points (Makharij)",
      "Final assessment and certification"
    ],
    requirements: [
      "No prior knowledge of Arabic is required",
      "Basic understanding of Arabic alphabet is helpful but not necessary",
      "Consistent internet connection for online classes",
      "Dedication to practice regularly between sessions"
    ],
    outcomes: [
      "Ability to recognize and pronounce all Arabic letters correctly",
      "Confidence in reading Quranic text with basic Tajweed",
      "Understanding of basic articulation points (Makharij)",
      "Foundation for further Quranic studies and memorization",
      "Certification upon successful completion"
    ],
    price: "Starting at $50/month",
    duration: "3-6 months (depends on pace)",
    level: "Beginner",
    instructor: "Qualified Quranic Tutors",
    language: "English & Arabic",
    certificateOffered: true
  },
  {
    id: "memorization",
    title: "Quran Memorization (Hifz)",
    description: "Memorize the Holy Quran under the guidance of experienced Huffaz with proven techniques.",
    icon: "fas fa-quran",
    iconColor: "text-emerald-500",
    bgColor: "bg-emerald-500 bg-opacity-20",
    tags: ["All Levels", "Structured Program", "Certification"],
    longDescription: `Our Quran Memorization (Hifz) program is a structured, comprehensive course designed to help students of all ages memorize the entire Quran or selected portions based on their goals and capacity.

The program utilizes proven memorization techniques taught by experienced Huffaz (those who have memorized the entire Quran) who guide students through the process with personalized attention and regular assessments.

Our approach combines traditional memorization methods with modern teaching techniques to ensure effective retention and proper recitation.`,
    curriculum: [
      "Assessment of current Quranic knowledge and reading ability",
      "Setting realistic memorization goals and timelines",
      "Techniques for effective memorization and retention",
      "Daily assignments for new memorization and revision",
      "Regular recitation and assessment sessions",
      "Proper Tajweed application during memorization",
      "Strategies for long-term retention",
      "Certification upon completion of memorization goals"
    ],
    requirements: [
      "Ability to read the Quran with basic fluency",
      "Commitment to daily practice and memorization",
      "Regular attendance of online sessions",
      "Dedication to revision and retention"
    ],
    outcomes: [
      "Memorization of selected portions or the entire Quran",
      "Improved recitation with proper Tajweed",
      "Enhanced connection with the Quran",
      "Development of discipline and memory skills",
      "Certification for completed portions"
    ],
    price: "Starting at $80/month",
    duration: "Customized based on goals",
    level: "All Levels",
    instructor: "Certified Huffaz",
    language: "English & Arabic",
    certificateOffered: true
  },
  {
    id: "tajweed",
    title: "Learn Tajweed Rules",
    description: "Perfect your Quranic recitation with comprehensive Tajweed rules and practice.",
    icon: "fas fa-language",
    iconColor: "text-primary",
    bgColor: "bg-primary bg-opacity-20",
    tags: ["Intermediate", "Live Classes", "Assessment"],
    longDescription: `Our Tajweed Rules course is designed to help students perfect their Quranic recitation by mastering the rules of Tajweed - the set of rules governing the pronunciation during the recitation of the Quran.

This course covers all essential Tajweed rules including heavy and light letters, stopping points, elongation (madd), and other principles that ensure the Quran is recited exactly as it was revealed to Prophet Muhammad (peace be upon him).

Through personalized instruction and regular practice, students will develop the ability to recognize, understand, and correctly apply these rules in their recitation.`,
    curriculum: [
      "Introduction to the importance of Tajweed",
      "Articulation points of letters (Makharij Al-Huroof)",
      "Characteristics of letters (Sifaat Al-Huroof)",
      "Rules of Noon Sakinah and Tanween",
      "Rules of Meem Sakinah",
      "Various types of Madd (elongation)",
      "Rules of stopping (Waqf) and starting (Ibtida)",
      "Common mistakes in Tajweed and how to avoid them",
      "Practical application through recitation practice"
    ],
    requirements: [
      "Ability to read Quranic Arabic with basic fluency",
      "Completion of basic Quran reading course or equivalent knowledge",
      "Commitment to regular practice between classes",
      "Recording device for self-assessment (smartphone is sufficient)"
    ],
    outcomes: [
      "Ability to recite the Quran according to the rules of Tajweed",
      "Understanding of all major Tajweed rules and their application",
      "Improved articulation of Arabic letters from their proper points",
      "Ability to identify and correct common Tajweed mistakes",
      "Enhanced beauty and accuracy in Quranic recitation"
    ],
    price: "Starting at $65/month",
    duration: "4-8 months",
    level: "Intermediate",
    instructor: "Certified Tajweed Specialists",
    language: "English & Arabic",
    certificateOffered: true
  }
];

// Article data
export const articles = [
  {
    id: "tajweed-importance",
    title: "The Importance of Tajweed in Quranic Recitation",
    titleArabic: "أهمية التجويد في تلاوة القرآن",
    description: "Understanding why proper Tajweed is essential for correct Quranic recitation and its spiritual benefits.",
    image: "https://images.unsplash.com/photo-1609599006353-e629aaabfeae?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
    category: "Tajweed",
    date: "October 15, 2023"
  },
  {
    id: "memorization-techniques",
    title: "Effective Quran Memorization Techniques",
    titleArabic: "حفظ القرآن",
    description: "Practical tips and strategies to help you memorize the Quran more effectively and retain what you've learned.",
    image: "https://images.unsplash.com/photo-1585036156261-1e2ac055427b?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
    category: "Memorization",
    date: "November 3, 2023"
  },
  {
    id: "arabic-learning",
    title: "The Path to Understanding Quran",
    titleArabic: "تعلم اللغة العربية",
    description: "How learning Arabic enhances your understanding of the Quran and deepens your connection with Allah's words.",
    image: "https://images.unsplash.com/photo-1604881988758-f76ad2f7aac1?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
    category: "Arabic Language",
    date: "December 7, 2023"
  },
  {
    id: "quran-rules",
    title: "Basic Rules of Quran Recitation",
    titleArabic: "قواعد التلاوة الأساسية",
    description: "Learn the fundamental rules that every beginner should know when starting their journey with Quran recitation.",
    image: "https://images.unsplash.com/photo-1542816417-0983674e29ab?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
    category: "Tajweed",
    date: "January 12, 2024"
  },
  {
    id: "ramadan-preparation",
    title: "Preparing for Ramadan with Quran",
    titleArabic: "الاستعداد لرمضان مع القرآن",
    description: "Simple ways to strengthen your connection with the Quran before and during the blessed month of Ramadan.",
    image: "https://images.unsplash.com/photo-1564760055775-d63b17a55c44?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
    category: "Islamic Knowledge",
    date: "February 5, 2024"
  },
  {
    id: "urdu-tajweed",
    title: "قرآن کی تلاوت میں تجوید کی اہمیت",
    titleArabic: "اردو میں تجوید کو سمجھنا",
    description: "آسان اردو زبان میں تجوید کے اصول سیکھیں اور اپنی قرآن کی تلاوت کو بہتر بنائیں۔",
    image: "https://images.unsplash.com/photo-1568687924505-e8c4bb1e3d90?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
    category: "Urdu Articles",
    date: "March 18, 2024"
  },
  {
    id: "urdu-quran-learning",
    title: "قرآن مجید سیکھنے کے آسان طریقے",
    titleArabic: "تعلم القرآن باللغة الأردية",
    description: "بچوں اور بڑوں کے لیے قرآن مجید سیکھنے کے آسان اور مؤثر طریقے جن سے آپ گھر پر بھی قرآن سیکھ سکتے ہیں۔",
    image: "https://images.unsplash.com/photo-1607249895875-de519e5cc4b6?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
    category: "Urdu Articles",
    date: "March 25, 2024"
  },
  {
    id: "urdu-ramadan",
    title: "رمضان میں قرآن کے ساتھ خصوصی تعلق",
    titleArabic: "شھر رمضان الذي أنزل فيه القرآن",
    description: "رمضان المبارک میں قرآن مجید کے ساتھ گہرا تعلق بنانے کے طریقے اور اس مہینے میں قرآنی اعمال کی فضیلت۔",
    image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
    category: "Urdu Articles",
    date: "April 1, 2024"
  },
  {
    id: "quranic-etiquette",
    title: "Etiquettes of Reciting the Holy Quran",
    titleArabic: "آداب تلاوة القرآن الكريم",
    description: "Learn about the proper manners and respect that should be observed when reading and handling the Quran.",
    image: "https://images.unsplash.com/photo-1580537659466-0a9bfa916a54?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
    category: "Islamic Knowledge",
    date: "April 2, 2024"
  }
];

// Testimonial data
export const testimonials = [
  {
    id: "1",
    text: "Alhamdulillah! I've been learning with Altarteel Academy for 6 months and my Quranic recitation has improved significantly. The teachers are patient and very knowledgeable.",
    name: "Ahmed S.",
    role: "Quran Reading Student"
  },
  {
    id: "2",
    text: "The Tajweed course has transformed my recitation. I appreciate how the teachers focus on each rule and make sure we understand before moving forward. Highly recommended!",
    name: "Fatima R.",
    role: "Tajweed Student"
  },
  {
    id: "3",
    text: "As a parent, I'm extremely satisfied with my children's progress in their Hifz program. The flexible schedule and personalized attention are exactly what we needed.",
    name: "Muhammad K.",
    role: "Parent"
  }
];
