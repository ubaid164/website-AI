import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import CourseDetails from "@/pages/course-details";
import Articles from "@/pages/articles";
import Contact from "@/pages/contact";
import About from "@/pages/about";
import ContactButtons from "./components/layout/ContactButtons";
import Header from "./components/layout/Header";
import Footer from "./components/layout/Footer";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/course/:id" component={CourseDetails} />
      <Route path="/articles" component={Articles} />
      <Route path="/article/:id" component={Articles} />
      <Route path="/contact" component={Contact} />
      <Route path="/about" component={About} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <div className="flex flex-col min-h-screen islamic-pattern">
      <Header />
      <main className="flex-grow">
        <Router />
      </main>
      <Footer />
      <ContactButtons />
      <Toaster />
    </div>
  );
}

export default App;
