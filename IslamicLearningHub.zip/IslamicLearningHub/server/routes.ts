import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { featuredCourses, articles, testimonials } from "../client/src/lib/data";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  app.get("/api/featured-courses", (_req, res) => {
    res.json(featuredCourses);
  });

  app.get("/api/courses/:id", (req, res) => {
    const { id } = req.params;
    const course = featuredCourses.find(course => course.id === id);
    
    if (!course) {
      return res.status(404).json({ message: "Course not found" });
    }
    
    res.json(course);
  });

  app.get("/api/articles", (_req, res) => {
    res.json(articles);
  });

  app.get("/api/articles/all", (_req, res) => {
    res.json(articles);
  });

  app.get("/api/testimonials", (_req, res) => {
    res.json(testimonials);
  });

  app.post("/api/contact", (req, res) => {
    const { name, email, phone, subject, message } = req.body;
    
    // Validate required fields
    if (!name || !email || !phone || !subject || !message) {
      return res.status(400).json({ message: "All fields are required" });
    }
    
    // Here you would typically store the contact form data or send an email
    // For now, we'll just send a success response
    res.status(200).json({ message: "Contact form submitted successfully" });
  });

  const httpServer = createServer(app);
  return httpServer;
}
